package com.example.connpeo;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.target.CustomTarget;
import com.bumptech.glide.request.transition.Transition;

import java.util.ArrayList;
import java.util.List;

public class RecentlyViewedAdapter extends RecyclerView.Adapter<RecentlyViewedAdapter.RecentlyViewedViewHolder> {
    Context context;
    List<RecentlyViewed> luntanRecentlyViewedList= new ArrayList<>();
    private Bitmap bitmap;
    private Bitmap imgBitmap = null;

    public RecentlyViewedAdapter(Context context, List<RecentlyViewed> luntanRecentlyViewedList) {
        this.context = context;
        this.luntanRecentlyViewedList = luntanRecentlyViewedList;
    }

    @NonNull
    @Override
    public RecentlyViewedViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.recently_viewed_items, parent, false);
        RecentlyViewedViewHolder viewHolder = new RecentlyViewedViewHolder(view);
        return new RecentlyViewedViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RecentlyViewedViewHolder holder, final int position) {
        final RecentlyViewed user = luntanRecentlyViewedList.get(position);
        holder.name.setText((CharSequence) luntanRecentlyViewedList.get(position).getName());
        String url = (String) luntanRecentlyViewedList.get(position).getimg();
        Glide.with(holder.img.getContext()).asBitmap().load(url).into(new CustomTarget<Bitmap>() {
            @SuppressLint("ClickableViewAccessibility")
            @Override
            public void onResourceReady(@NonNull Bitmap resource, @Nullable Transition<? super Bitmap> transition) {
                imgBitmap = resource;
                holder.img.setImageBitmap(imgBitmap);
            }
            @Override
            public void onLoadCleared(@Nullable Drawable placeholder) {

            }
        });

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(context, Perdet.class);
                i.putExtra("name", (CharSequence) luntanRecentlyViewedList.get(position).getName());
                i.putExtra("beiyong", (CharSequence) luntanRecentlyViewedList.get(position).getbeiyong());
                i.putExtra("tel", (String) luntanRecentlyViewedList.get(position).gettel());
                i.putExtra("img", (String) luntanRecentlyViewedList.get(position).getimg());
                i.putExtra("fenzu", (String) luntanRecentlyViewedList.get(position).getfenzu());
                context.startActivity(i);

            }
        });

        String mark = luntanRecentlyViewedList.get(position).getStart();
        if (position == getPosition(mark)){
            holder.letterlayout.setVisibility(View.VISIBLE);
            holder.letter.setText(luntanRecentlyViewedList.get(position).getStart());
        }else {
            holder.letterlayout.setVisibility(View.GONE);
        }

        if (position!=getItemCount()-1&&luntanRecentlyViewedList.get(position).getStart().equalsIgnoreCase(luntanRecentlyViewedList.get(position+1).getStart())){
            holder.underline.setVisibility(View.VISIBLE);
        }else {
            holder.underline.setVisibility(View.GONE);
        }

    }

    private int getPosition(String mark) {
        for (int i=0;i<getItemCount();i++){
            if (luntanRecentlyViewedList.get(i).getStart().equalsIgnoreCase(mark)){
                return i;
            }
        }
        return -1;
    }

    @Override
    public int getItemCount() {
        return luntanRecentlyViewedList.size();
    }

    public  static class RecentlyViewedViewHolder extends RecyclerView.ViewHolder{
        LinearLayout letterlayout;
        TextView letter;
        TextView name;
        ImageView img;
        View view;
        View underline;

        public RecentlyViewedViewHolder(@NonNull View itemView) {
            super(itemView);

            name = itemView.findViewById(R.id.name);
            img = itemView.findViewById(R.id.img);
            letter = itemView.findViewById(R.id.letter);
            letterlayout = itemView.findViewById(R.id.letterlayout);
            view = itemView;
            underline = itemView.findViewById(R.id.underline);
        }
    }

}