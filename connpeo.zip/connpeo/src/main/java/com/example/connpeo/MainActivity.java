package com.example.connpeo;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeSet;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {

    RecyclerView  recentlyViewedRecycler;
    RecentlyViewedAdapter recentlyViewedAdapter;
    private LinearLayout layoutIndex;
    private DatabaseHelper databaseHelper;
    private String id="1";// 定义一个输入id的编辑框组件
    private Handler handler; // 定义一个android.os.Handler对象
    private String result = "",params=""; // 定义一个代表显示内容的字符串
    private String name="",beiyong="",tel="",img, fenzu;
    private ImageView sea,add;
    List<RecentlyViewed> luntanRecentlyViewedList = new ArrayList<>();
    List<Map<String,Object>> List = new ArrayList<Map<String,Object>>();
    SideBar sideBar;
    private TextView fz;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recentlyViewedRecycler = findViewById(R.id.recently_item);
        sideBar = findViewById(R.id.sidebar);

        sea = findViewById(R.id.sea);
        sea.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(MainActivity.this, Search.class);
                startActivity(i);
                finish();
            }
        });

        add = findViewById(R.id.add);
        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(MainActivity.this, Add.class);
                startActivity(i);
                finish();
            }
        });

        fz = findViewById(R.id.fz);
        fz.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(MainActivity.this, Fenzu.class);
                startActivity(i);
                finish();
            }
        });

        // 创建数据库助手实例
        databaseHelper = new DatabaseHelper(this);

        //databaseHelper.insertData("a", "a","aaaa","https://i1.hdslb.com/bfs/archive/94905ad84fb925eb37fa7eec69f79cd242454782.jpg","同学");
        //databaseHelper.insertData("b", "b","aaaa","https://img1.baidu.com/it/u=468944751,673676941&fm=253&fmt=auto&app=138&f=JPEG?w=500&h=500","同事");
        //databaseHelper.insertData("e", "e","eeee","https://q7.itc.cn/q_70/images03/20240423/6d236fae5c8f44ed9b60d977f32debb7.jpeg","其它");
        //databaseHelper.insertData("d", "d","aaaa","https://p1.itc.cn/q_70/images03/20220714/e3e968b1d3484c70a00a1c130472c91f.jpeg","家人");

        // 查询数据
        new Thread(() -> {
            List<RecentlyViewed> dataList = databaseHelper.queryDataA();
            for (int i = 0; i < dataList.size(); i++) {
                RecentlyViewed fenzued = dataList.get(i);
                // 访问 fenzued 对象的属性
                String name = fenzued.getName();
                String beiyong = fenzued.getbeiyong();
                String tel = fenzued.gettel();
                String img = fenzued.getimg();
                String fenzu = fenzued.getfenzu();
                // ...
                luntanRecentlyViewedList.add(new RecentlyViewed(name, beiyong,  tel, img, fenzu));
                setRecentlyViewedRecycler(luntanRecentlyViewedList);
                Collections.sort(luntanRecentlyViewedList);
            }
        }).start();

    }

    private void setRecentlyViewedRecycler(List<RecentlyViewed> recentlyViewedDataList) {
        RecyclerView.LayoutManager layoutManager = new GridLayoutManager(MainActivity.this,1);
        recentlyViewedRecycler.setLayoutManager(layoutManager);
        recentlyViewedAdapter = new RecentlyViewedAdapter(this,recentlyViewedDataList);
        recentlyViewedRecycler.setAdapter(recentlyViewedAdapter);

        sideBar.setOnStrSelectCallBack(new SideBar.ISideBarSelectCallBack() {
            @Override
            public void onSelectStr(int index, String selectStr) {
                for (int i = 0; i < recentlyViewedDataList.size(); i++) {
                    if (selectStr.equalsIgnoreCase(recentlyViewedDataList.get(i).getStart())){
                        recentlyViewedRecycler.scrollToPosition(i);
                        return;
                    }
                }
            }
        });
    }

}